package com.example.demo.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MemberVO {
	private	String	id	;
	private	String	pwd	;
	private	String	phone	;
	private	String	email	;
	private	String	m_name	;
	private	String	nickname	;
	private	Date	birth_date	;
	private	String	gender	;
	private	int	soccer	;
	private	int	footsal	;
	private	int	bascketBall	;
	private	int	footVolleyball	;
	private	String	m_img	;
	private	String	m_loc1	;
	private	String	m_loc2	;
	private	String	m_stat	;
	private 	String	role	;

}
