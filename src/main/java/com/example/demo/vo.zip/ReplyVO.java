package com.example.demo.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReplyVO {
	private	int	r_no	;
	private	int	b_no	;
	private	String	r_content	;
	private	Date	r_date	;
	private	String	id	;

}
