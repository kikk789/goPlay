package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AddressDistrictVO {
	private	int	ad_no	;
	private	String	ad_name	;
	private	int	ac_no	;
}
