package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FaqVO {
	private	int	faq_no	;
	private	String	faq_title	;
	private	String	faq_content	;

}
