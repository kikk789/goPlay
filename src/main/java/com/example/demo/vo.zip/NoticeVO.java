package com.example.demo.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NoticeVO {
	private	int	n_no	;
	private	String	n_title	;
	private	String	n_content	;
	private	String	n_img	;
	private	String	n_video	;
	private	String	n_file	;
	private	Date	n_date	;
	private	int	n_hit	;
	private	String	id	;
}
