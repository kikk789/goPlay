package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatchMemberVO {
	private	int	mm_no	;
	private	int	mb_no	;
	private	int	mo_no	;
	private	int	list_no	;
}
