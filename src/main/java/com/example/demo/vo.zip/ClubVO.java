package com.example.demo.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClubVO {
	private	int	c_no	;
	private	String	id	;
	private	String	c_name	;
	private	Date	c_date	;
	private	String	c_type	;
	private	String	c_loc1	;
	private	String	c_loc2	;
	private	String	c_img	;
	private	String	c_intro	;
	private	String	c_stat	;


}
