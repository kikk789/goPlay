package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StadiumVO {
	private	int	std_no	;
	 private	String	std_name	;
	private	String	std_type	;
	private	String	address	;
	private	String	tel	;
	 private	String	a_time	;
	private	String	holiday	;
	private	String	homepage	;
	private	String	std_img	;
	 private	String	std_loc1	;
	private	String	std_loc2	;
	private	String	latitude	;
	private	String	longitude	;
}
