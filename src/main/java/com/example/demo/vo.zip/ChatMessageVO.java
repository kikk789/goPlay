package com.example.demo.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChatMessageVO {
	private	int	msg_no	;
	private	String	msg	;
	private	String	msg_img	;
	private	String	msg_video	;
	private	String	msg_file	;
	private	Date	msg_time	;
	private	String	id	;
	private	int	r_no	;

}
