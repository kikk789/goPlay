package com.example.demo.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatchBoardVO {
	private	int	mb_no	;
	private	int	home_club	;
	private	int	away_club	;
	private	Date	mb_date	;
	private	String	mb_type	;
	private	String	mb_loc1	;
	private	String	mb_loc2	;
	private	String	mb_stadium	;
	private	int	mb_fee	;
	private	String	home_ucolor	;
	private	String	away_ucolor	;
	private	String	home_level	;
	private	String	away_level	;
	private	String	home_say	;
	private	String	away_say	;
	private	int	h_score	;
	private	int	a_score	;
	private	String	mb_stat	;
}
