package com.example.demo.vo;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BoardVO {
	private	int	b_no	;
	private	String	b_title	;
	private	String	b_content	;
	private	String	b_img	;
	private	String	b_video	;
	private	String	b_file	;
	private	Date	b_date	;
	private	int	b_hit	;
	private	Date	sch_date	;
	private	String	sch_place	;
	private	int	c_no	;
	private	int	b_type	;
	private	String	id	;
	private	MultipartFile	uploadFile	;


}
