package com.example.demo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatchRecordVO {
	private	int	rec_no	;
	private	int	mb_no	;
	private	int	c_no	;
	private	int	win	;
	private	int	draw	;
	private	int	lose	;


}
